const config = {
  apiUrl: 'http://localhost:4784'
};

export default config;